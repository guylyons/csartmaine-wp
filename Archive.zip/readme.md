# DeepFried
A simple, stripped down web scaffolding template.

# About
Some of my favorite and most frequently used packages are included. I find these useful; maybe you will, too. 

# Getting Started
To get started:

    npm install && bower install
    gulp serve
  
After packages have installed, use the Gulp to watch for changes.

# Gulp CLI
Watch for changes
 
    gulp serve

# What's included
- Gulp
- Sass & Babel
- PostCSS: Autoprefixer, Lost Grid
- Evil Icons, BrowserSync
